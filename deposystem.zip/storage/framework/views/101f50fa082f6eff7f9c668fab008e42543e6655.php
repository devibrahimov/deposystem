<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="main-content">


        <div class="responsiveTable p-1">
            <table class="table mt-3 table-bordered text-center">
                <thead>
                <tr>
                    <th scope="col" style="width: 5%;">№</th>
                    <th scope="col" style="width: 20%;">Layhiə</th>
                    <th scope="col" style="width: 15%;">Tarix</th>
                    <th scope="col" style="width: 30%;">Status</th>
                    <th colspan="2" style="width: 30%;">Redaktə</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($post->id); ?></th>
                        <td><?php echo e($post->project_name); ?></td>
                        <td><?php echo e($post->created_at); ?></td>
                        <td><?php echo e(poststatus($post->status)); ?> </td>
                        <td style="width:15%; background-color: #c7ffe1;">
                            <a style="text-decoration: none;"  href="<?php echo e(route('supervisorpostdetail',$post->id)); ?>">Bax</a>
                        </td>
                        <td style=" background-color: #ffcccc;"><a style="text-decoration: none;"  href="">Ləğv et</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <?php echo e($posts->links()); ?>

                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\deposystem\resources\views/Supervisor/account.blade.php ENDPATH**/ ?>