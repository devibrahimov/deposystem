<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href=" /imagegallery/simple-lightbox.css?v2.8.0" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="viewPage">
        <div class="medium d-flex justify-content-between align-items-center">
            <div class="d-flex flex-column justify-content-between" style="width: 300px;">
                <a class="btn btn-outline-info" style="width: 7.8rem;"   href="<?php echo e(route('ItDepartmentaccount')); ?>">  Sifarişlər</a>
                <a class="btn btn-outline-success mt-1" style="width: 7.8rem;" href="<?php echo e(route('ItDepartmentaddnewproduct')); ?>"><i
                        class="fas fa-plus pe-2"></i>Yeni  Sifariş</a>
                <table class="table mt-3 table-bordered text-center">
                    <thead">
                    <th scope="col">№</th>
                    <th scope="col"><?php echo e($post->id); ?></th>
                    </thead>
                    <tbody>
                    <tr>
                        <th scope="col">Layhiə</th>
                        <td><?php echo e($post->project_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Tarix</th>
                        <td><?php echo e($post->created_at); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Status</th>
                        <td><?php echo e(poststatus($post->status)); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="comment pb-2 pb-md-0" style="width: 250px;">
                <form action="<?php echo e(route('comment')); ?>" method="post" >
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($post->id); ?>" name="postid">
                    <textarea style="border-radius:4px 4px 0 0;" class="form-control" placeholder="Rəy və qeydlər" name="comment" rows="4"></textarea>
                    <button class="btn form-control btn-success" style="border-radius: 0 0 4px 4px;" type="submit">Əlavə et</button>
                </form>
            </div>

            <div class="button-group d-flex justify-content-center align-items-center flex-column">
                <button class="btn btn-outline-primary mt-3"
                        style="border: 1px solid #494949;border-radius: 4px;" type="submit"><i
                        class="fas fa-print"></i> Çap et</button>
                <button class="btn btn-outline-danger mt-3" type="submit"><i class="fas fa-times"></i> Ləğv
                    et</button>
            </div>
        </div>
        <div class="responsiveTable p-1">
            <table class="table mt-3 table-bordered text-center">
                <thead>
                <tr>
                    <th scope="col" style="width: 5%;">S/S</th>
                    <th scope="col" style="width: 25%;">Mal-materialın tam adı</th>
                    <th scope="col" style="width: 15%;">Təyinat</th>
                    <th scope="col" style="width: 15%;">Ölçü vahidi</th>
                    <th scope="col" style="width: 20%;">Miqdar</th>
                    <th scope="col" style="width: 20%;">Şəkil</th>
                </tr>
                </thead>
                <tbody >
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">1</th>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->destination); ?></td>
                        <td><?php echo e($product->valley_of_measure); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td>
                            <a href="/<?php echo e($product->image); ?>" class="btn btn-success image"
                                    style="padding: 0 20px;">Bax</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        Rəy
        <table class="table mt-3 table-bordered text-center">
            <tbody>
            <tr class="d-flex justify-content-center align-items-center">
                <td style="width: 20%;">02.08.2021 09:37</td>
                <td style="width: 15%;">Rəis</td>
                <td style="width: 75%;"><i class="far fa-play-circle text-success" style="font-size: 25px;"></i></td>
            </tr>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="d-flex justify-content-center align-items-center">
                <td style="width: 20%;"><?php echo e($comment->created_at); ?></td>
                <td style="width: 15%;"><?php echo e($comment->user->department); ?></td>
                <td style="width: 15%;"><?php echo e($comment->user->name); ?></td>
                <td style="width: 75%;" > <?php echo e($comment->content); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="/imagegallery/simple-lightbox.js?v2.8.0"></script>
    <script>
        (function(){
            var $gallery = new SimpleLightbox('tbody a.image', {});
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\deposystem\resources\views/ItDepartment/postdetail.blade.php ENDPATH**/ ?>