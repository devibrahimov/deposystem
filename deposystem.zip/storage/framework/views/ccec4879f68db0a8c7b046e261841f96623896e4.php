<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('updateproducts',$post->id)); ?>" method="post" enctype="multipart/form-data">
        <input class="ms-4 py-2 text-center" style="border:1px solid #1a1a1a;border-radius: 4px;" name="project_name"
               type="text" placeholder="<?php echo e($post->project_name); ?>" disabled required>

        <?php echo csrf_field(); ?>
        <div class="addPage mt-5 p-3 bg-light h-auto">
            <div class="responsiveTable p-1">
                <table>
                    <tbody id="tablebody">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width:25%;">
                                <input style="width:90%;" type="text"  disabled
                                       required placeholder="<?php echo e($product->name); ?>"></td>
                            <td style="width:20%;">
                                <input style="width:90%;" type="text"   
                                disabled    required placeholder="<?php echo e($product->destination); ?>">
                            </td>
                            <td style="width:10%;">
                                <input style="width:90%;" type="text"  
                                disabled  required placeholder="<?php echo e($product->valley_of_measure); ?>">
                            </td>
                            <td style="width:10%;">
                                <input style="width:90%;" type="text"   
                                disabled   required  placeholder="<?php echo e($product->quantity); ?>">
                            </td>
                            <td style="width:13%;">
                                <input style="width:90%;" type="text" disabled
                                    placeholder="<?php echo e($product->quantity_in_stock == 0 ? 'Anbarda Yoxdur': $product->quantity_in_stock); ?>" >
                            </td>



                            <td style="width:5%;" class="position-relative">
                                <img src="/<?php echo e($product->image); ?>" alt="" width="70px">
                            </td>
                            <td style="width:8%;" class="position-relative">

                                <select id="select" name="Decision_<?php echo e($product->id); ?>" required>
                                    <option <?php echo e($product->Decision == 'Təhvil verilsin'?'selected' : ''); ?> value="Təhvil verilsin">Təhvil verilsin</option>
                                    <option <?php echo e($product->Decision == 'Təmin olunsun'?'selected' : ''); ?> value="Təmin olunsun">Təmin olunsun</option>
                                    <option <?php echo e($product->Decision == 'Qəbul olunmadı'?'selected' : ''); ?> value="Qəbul olunmadı">Qəbul olunmadı</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        

        <div class="operation m-3 d-flex justify-content-end align-items-end">
            <button class="btn btn-success mt-3 me-2" type="submit">Göndər</button>
            <a class="btn btn-outline-danger mt-3" href="<?php echo e(redirect()->getUrlGenerator()->previous()); ?>">
                <i class="fas fa-left"></i>  Geri Qayıt</a>
        </div>

    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    
    

    

    
    
    
    
    
    
    
    

    
    
    
    

    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\deposystem\resources\views/reiseditproducts.blade.php ENDPATH**/ ?>