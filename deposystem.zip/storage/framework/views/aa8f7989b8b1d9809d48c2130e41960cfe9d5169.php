<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="main-content mt-5">
        <div class="responsiveTable p-1">
            <table class="table mt-3 table-bordered text-center">
                <thead>
                <tr>
                    <th scope="col" style="width: 5%;">Log №</th>
                    <th scope="col" style="width: 20%;">İstifadəçi</th>
                    <th scope="col" style="width: 10%;">log</th>
                    <th scope="col" style="width: 20%;">Tarix Saat</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($log->id); ?></th>
                        <td><?php echo e($log->user->name); ?></td>
                        <td><?php echo e($log->message); ?></td>
                        <td><?php echo e($log->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <?php echo e($logs->links()); ?>

            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\deposystem\resources\views/logs.blade.php ENDPATH**/ ?>